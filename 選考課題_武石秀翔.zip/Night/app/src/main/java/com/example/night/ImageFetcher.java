package com.example.night;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.ImageView;

import com.example.night.R;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.MalformedInputException;


public class ImageFetcher extends AsyncTask<String ,Void,Bitmap> {

    public ImageFetcher(ImageView image) {
        imageView = image;
    }

    private ImageView imageView;

    @Override
    //引数のURLからBitmapを取得。
    protected Bitmap doInBackground(String... strings) {
        try {
            URL url = new URL(strings[0]);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            Bitmap bitmap = BitmapFactory.decodeStream(connection.getInputStream());
            return Bitmap.createScaledBitmap(bitmap, 200, 200, false);
        } catch (Resources.NotFoundException e) {
            Log.e("ImageFetch", "wrong URL");
            return null;
        }catch (MalformedInputException e){
            Log.e("ImageFetch", "Invalid URL");
            return null;
        } catch (Exception e) {
            Log.e("ImageFetch", e.toString());
            return null;
        }
    }
    @Override
    //取得したBitmapをImageViewにセットする。取得失敗ならNO_IMAGE。
    protected void onPostExecute(Bitmap bitmap) {
        if (bitmap == null) {
            imageView.setImageResource(R.drawable.no_image_100);
        }
        else imageView.setImageBitmap(bitmap);
    }
}
