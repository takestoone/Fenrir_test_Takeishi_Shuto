package com.example.night;

import android.app.Activity;
import android.content.res.Resources;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.JsonReader;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class APICaller extends AsyncTask<Bundle,Void,JSONArray> {
    public String buildQuery(Bundle bundle) {
        Resources resources = MainActivity.getMainActivity().getResources();
        StringBuilder builder = new StringBuilder(resources.getString(R.string.API_url));
        String name = bundle.getString(resources.getString(R.string.APICall_name));
        if (name != null && !name.isEmpty()) {
            builder.append("&name=" + name);
        }
        builder.append("&offset_page=" + bundle.getInt(resources.getString(R.string.APICall_page)));
        builder.append("&latitude=" + bundle.getDouble(resources.getString(R.string.APICall_latitude)));
        builder.append("&longitude=" + bundle.getDouble(resources.getString(R.string.APICall_longitude)));
        builder.append("&range=" + bundle.getInt(resources.getString(R.string.APICall_range)));
        builder.append("&private_room=" + bundle.getInt(resources.getString(R.string.APICall_privateRoom)));
        builder.append("&midnight=" + bundle.getInt(resources.getString(R.string.APICall_mid_night)));
        builder.append("&until_morning=" + bundle.getInt(resources.getString(R.string.option_until_morning)));
        builder.append("&no_smoking=" + bundle.getInt(resources.getString(R.string.APICall_no_smoking)));
        builder.append("&buffet=" + bundle.getInt(resources.getString(R.string.option_buffet)));
        builder.append("&bottomless_cup=" + bundle.getInt(resources.getString(R.string.APICall_free_drink)));
        return builder.toString();
    }

    private SearchFragment searchFragment;

    public APICaller(SearchFragment fragment) {
        searchFragment = fragment;
    }

    HttpURLConnection getConnection(String query) {
        HttpURLConnection connection = null;
        try {
            URL url = new URL(query);
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            connection.setDoInput(true);
            connection.setConnectTimeout(1000000);
            connection.setReadTimeout(10000);
            return connection;
        } catch (Exception e) {
            Log.e("APIError", "failed to connect");
            return null;
        }
    }

    String getResponse(HttpURLConnection connection) {
        try {
            StringBuilder builder = new StringBuilder();
            InputStream is = connection.getInputStream();
            InputStreamReader isr = new InputStreamReader(is);
            BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream(), "UTF8"), 102400);
            String line;
            while ((line = reader.readLine()) != null) {
                builder.append(line + "\n");
            }
            return builder.toString();
        } catch (IOException e) {
            Log.e("APICall.response", e.toString());
            return null;
        }
    }

    @Override
    //ぐるなびAPIにクエリを送信、結果をJSONArrayとして返す。
    protected JSONArray doInBackground(Bundle... bundles) {
        HttpURLConnection connection = getConnection(buildQuery(bundles[0]));
        String response = getResponse(connection);
        if(response==null) {
            searchFragment.setErrorCode(MainActivity.getMainActivity().getResources().getInteger(R.integer.API_Error_NoResult));
            return null;
        }
        JSONArray jsonArray = null;
        try {
            JSONObject result = new JSONObject(response);
            if(result.optJSONObject("error") != null) {
                searchFragment.setPageCount(0);
                searchFragment.setErrorCode(result.getJSONObject("error").getInt("code"));
                return null;
            }
            searchFragment.setPageCount(getPageCount(result));
            //endregion
            jsonArray = result.getJSONArray("rest");
            return jsonArray;
        } catch (JSONException e) {
            Log.e("APICall", e.toString());
            return null;
        } catch (Exception e) {
            Log.d("APICall", e.toString());
            return null;
        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    private int getPageCount(JSONObject jsonObject) {
        try {
            int total = jsonObject.getInt("total_hit_count");
            int hitPerPage = jsonObject.getInt("hit_per_page");
            int pageCount = (total / hitPerPage);
            pageCount += (total % hitPerPage != 0) ? 1 : 0;
            return pageCount;
        }catch (JSONException e) {
            Log.e("APICall.pageCount", e.toString());
            return 0;
        }
    }
}
