package com.example.night;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.FrameLayout;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class DetailFragment extends Fragment {
    private JSONObject restaurant;
    private View inflatedView;
    private CheckBox favoriteCheck;
    private String restaurantID;

    //「お気に入り」に追加済みかどうかを問い合わせる。
    private boolean isRegistered() {
        JSONArray favorite = MainActivity.getMainActivity().getFavoriteFragment().getFavoriteRestaurants();
        try {
            for (int i = 0; i < favorite.length(); i++) {
                if (restaurantID.equals(favorite.getJSONObject(i).getString("id"))) return true;
            }
        } catch (JSONException e) {
            Log.e("D_Fragment", "isRegisterer: " + e.toString());
        }
        return false;
    }

    public void setRestaurant(JSONObject restaurantJson) {
        restaurant = restaurantJson;
        try {
            restaurantID = restaurant.getString("id");
        } catch (JSONException e) {
            Log.e("D_Fragment", "isSet: " + e.toString());
        }
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup group, Bundle bundle) {
        super.onCreateView(inflater, group, bundle);
        //表示するべき情報がないときは専用の画面を表示
        if (restaurant == null) return inflater.inflate(R.layout.detail_null_view, group, false);
        return inflater.inflate(R.layout.detail_view, group, false);
    }

    @Override
    public void onViewCreated(View v, Bundle bundle) {
        super.onViewCreated(v, bundle);
        inflatedView = v;
        if (restaurant == null) return;
        try {
            ((TextView) inflatedView.findViewById(R.id.detail_head)).setText(restaurant.getString("name"));
            ((TextView) inflatedView.findViewById(R.id.detail_PR)).setText(restaurant.getJSONObject("pr").getString("pr_short"));
            ((TextView) inflatedView.findViewById(R.id.detail_telephpne)).setText(restaurant.getString("tel"));
            ((TextView) inflatedView.findViewById(R.id.detail_address)).setText(restaurant.getString("address"));
            JSONObject access = restaurant.getJSONObject("access");
            //region 店舗までのアクセスを取得
            String walk = access.getString("walk");
            try {
                Integer minute = Integer.parseInt(walk);
                walk = "徒歩" + minute + "分";
            } catch (Exception e) {
                walk += "分";
            }
            String accessInfo =
                    access.getString("line")
                            + access.getString("station")
                            + access.getString("station_exit") + "\n\t\t\t"
                            + walk;
            //endregion
            ((TextView) inflatedView.findViewById(R.id.detail_access)).setText(accessInfo);
            ((TextView) inflatedView.findViewById(R.id.detail_openTIme)).setText(restaurant.getString("opentime"));
            ((TextView) inflatedView.findViewById(R.id.detail_budget)).setText(restaurant.getString("budget") + "円");
            ((TextView) inflatedView.findViewById(R.id.detail_URL)).setText(restaurant.getString("url"));
            new ImageFetcher(inflatedView.findViewById(R.id.detail_thumbnail)).execute(restaurant.getJSONObject("image_url").getString("shop_image1"));
        } catch (JSONException e) {
            Log.e("D_Fragment_setJson", e.toString());
        }
        addFavoriteCheckButton();
    }

    //画面表示の際にイベントが呼ばれてしまうので、後付けで追加する。
    private void addFavoriteCheckButton() {
        favoriteCheck = new CheckBox(MainActivity.getMainActivity());
        favoriteCheck.setOnCheckedChangeListener(null);
        favoriteCheck.setChecked(isRegistered());
        favoriteCheck.setText("お気に入りに追加");
        favoriteCheck.setOnCheckedChangeListener((view, checked) -> {
            if (checked) {
                view.setText("お気に入りに追加済み");
                if (!isRegistered()) {
                    MainActivity.getMainActivity().getFavoriteFragment().addFavorite(restaurant);
                    Log.d("D_Fragment", "add");
                }
            } else {
                view.setText("お気に入りに追加");
                MainActivity.getMainActivity().getFavoriteFragment().removeFavorite(restaurant);
                Log.d("D_Fragment", "remove");
            }
        });
        ((FrameLayout) inflatedView.findViewById(R.id.checkContainer)).addView(favoriteCheck);
    }
}
