package com.example.night;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

public class FavoriteFragment extends Fragment {
    private View inflatedView;
    private JSONObject favorite;
    public JSONArray getFavoriteRestaurants() {
        try {
            return favorite.getJSONArray("rest");
        } catch (JSONException e) {
            Log.e("F_Fragment", e.toString());
            return null;
        }
    }
    private RecyclerView recyclerView;

    //region Fileアクセス
    private JSONObject loadFavoriteFile() {
        try {
            FileInputStream inputStream = MainActivity.getMainActivity().openFileInput(getString(R.string.favorite_FilePath));
            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
            StringBuilder builder = new StringBuilder();
            String line = reader.readLine();
            while (line != null) {
                builder.append(line + "\n");
                line = reader.readLine();
            }
            return new JSONObject(builder.toString());
        } catch (Exception e) {
            Log.e("F_Fragment", "read " + e.toString());
            return null;
        }
    }

    public void saveFavoriteFile() {
        if (favorite == null) return;
        FileOutputStream outputStream = null;
        BufferedWriter writer = null;
        try {
            outputStream = MainActivity.getMainActivity().openFileOutput(getString(R.string.favorite_FilePath), Context.MODE_PRIVATE);
            writer = new BufferedWriter(new OutputStreamWriter(outputStream));
            writer.write(favorite.toString());
            writer.close();
            outputStream.close();
        } catch (Exception e) {
            Log.e("F_Fragment", "save " + e.toString());
        }
    }

    //endregion


    private boolean isFavoriteFileExist() {
        MainActivity main = MainActivity.getMainActivity();
        String filepath = main.getFilesDir().getAbsolutePath() + "/" + getString(R.string.favorite_FilePath);
        File file = new File(filepath);
        return file.exists();
    }

    private void  readFavorites() {
        if (!isFavoriteFileExist() || (favorite = loadFavoriteFile()) == null) {
            initFavorite();
        }
    }
    private void initFavorite(){
        favorite = new JSONObject();
        try {
            favorite.put("rest", new JSONArray());
        } catch (JSONException e) {
            Log.e("F_Fragment", "init: " + e.toString());
        }
    }

    public void addFavorite(JSONObject restaurant) {
        try {
            favorite.getJSONArray("rest").put(restaurant);
        } catch (JSONException e) {
            Log.e("F_Fragment", "add " + e.toString());
        }
    }
    public void removeFavorite(JSONObject restaurant) {
        try {
            JSONArray array = favorite.getJSONArray("rest");
            for (int i = 0; i < array.length(); i++) {
                JSONObject jsonObject = array.getJSONObject(i);
                if (jsonObject.getString("id").equals(restaurant.getString("id"))) {
                    array.remove(i);
                    return;
                }
            }
        } catch (JSONException e) {
            Log.e("F_Fragment", "remove " + e.toString());
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup group, Bundle bundle) {
        super.onCreateView(inflater, group, bundle);
        if (favorite == null) readFavorites();
        return inflater.inflate(R.layout.favorite_view, group, false);
    }

    @Override
    public void onViewCreated(View v, Bundle bundle) {
        super.onViewCreated(v, bundle);
        inflatedView = v;
        recyclerView = inflatedView.findViewById(R.id.favorite_recycler);
        RecyclerView.LayoutManager manager = new LinearLayoutManager(MainActivity.getMainActivity());
        recyclerView.setHasFixedSize(true);
        manager.offsetChildrenVertical(5);
        recyclerView.setLayoutManager(manager);
        showFavorite();
    }

    @Override
    public void onDetach(){
        super.onDetach();
        saveFavoriteFile();
    }

    private void showFavorite() {
        if (favorite == null) return;
        try {
            JSONArray array = favorite.getJSONArray("rest");
            recyclerView.setAdapter(new ResultAdapter(array));
        } catch (JSONException e) {
            Log.e("F_Fragment", "show " + e.toString());
        }
    }
}
