package com.example.night;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.PermissionChecker;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity implements LocationListener {
    private static MainActivity mainActivity;
    public static MainActivity getMainActivity(){return mainActivity;}

    public BottomNavigationView bottomNavigationView;

    private static String[] PERMISSIONS=new String[]{Manifest.permission.ACCESS_FINE_LOCATION};
    private LocationManager locationManager;

    private SearchFragment searchFragment;
    public SearchFragment getSearchFragment() {
        return searchFragment;
    }

    private DetailFragment detailFragment;
    public DetailFragment getDetailFragment() {
        return detailFragment;
    }

    private FavoriteFragment favoriteFragment;
    public FavoriteFragment getFavoriteFragment() {
        return favoriteFragment;
    }

    private Fragment previousFragment;
    private int viewMode;

    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = item -> {
        switch (item.getItemId()) {
            case R.id.navigation_search:
                replaceContent(R.integer.Navigation_Search);
                return true;
            case R.id.navigation_detail:
                replaceContent(R.integer.Navigation_Detail);
                return true;
            case R.id.navigation_favorite:
                replaceContent(R.integer.Navigation_Favorite);
                return true;
        }
        return false;
    };

    //region Life Cycle
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mainActivity = this;
        setContentView(R.layout.activity_main);
        viewMode = -1;
        replaceContent(R.integer.Navigation_Favorite);
        replaceContent(R.integer.Navigation_Search);
        bottomNavigationView = findViewById(R.id.nav_view);
        bottomNavigationView.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        requestLocationPermission();
    }

    @Override
    protected void onResume() {
        super.onResume();
        setGPSEnabled(true);
    }

    @Override
    protected void onPause() {
        super.onPause();
        setGPSEnabled(false);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        //「お気に入り」をファイルに保存。
        if (favoriteFragment != null) favoriteFragment.saveFavoriteFile();
    }
    //endregion

    //表示するFragmentを切り替える。
    private void replaceContent(int navigationType) {
        if (viewMode == navigationType) return;//同じ画面への遷移は何もしない。
        viewMode = navigationType;
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        if (previousFragment != null) transaction.remove(previousFragment);
        previousFragment = null;
        switch (navigationType) {
            case R.integer.Navigation_Search://region 検索画面
                if (searchFragment == null) searchFragment = new SearchFragment();
                transaction.add(R.id.container, searchFragment);
                previousFragment = searchFragment;
                break;//endregion
            case R.integer.Navigation_Detail://region 詳細画面
                if (detailFragment == null) detailFragment = new DetailFragment();
                transaction.add(R.id.container, detailFragment);
                previousFragment = detailFragment;
                break;
            //endregion
            case R.integer.Navigation_Favorite://region お気に入り画面
                if (favoriteFragment == null) favoriteFragment = new FavoriteFragment();
                transaction.add(R.id.container, favoriteFragment);
                previousFragment = favoriteFragment;
                break;
            //endregion
        }
        transaction.commit();
    }
    public void showDetail() {
        replaceContent(R.integer.Navigation_Detail);
        bottomNavigationView.getMenu().findItem(R.id.navigation_detail).setChecked(true);
    }


    //region Permission
    private void setGPSEnabled(boolean enabled){
        if (!isLocationGranted()) {
            requestLocationPermission();
            return;
        }
        if(enabled) {
            try {
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 30000, 50, this);
            }catch (SecurityException e) {
                Log.e("GPS_Enable", e.toString());
            }
        }else {
            locationManager.removeUpdates(this);
        }
    }
    private void requestLocationPermission() {
        if (!isLocationGranted())
            ActivityCompat.requestPermissions(this, PERMISSIONS, getResources().getInteger(R.integer.Permission_Request_GPS));
    }
    private Boolean isLocationGranted() {
        for (int i = 0; i < PERMISSIONS.length; i++) {
            if (PermissionChecker.checkCallingOrSelfPermission(this, PERMISSIONS[i]) != PackageManager.PERMISSION_GRANTED) {
                return false;
            }
        }
        return true;
    }
    //endregion

   //region GPS
    @Override
    public void onLocationChanged(Location location) {
        if (searchFragment != null)
            searchFragment.setLatLon(location.getLatitude(), location.getLongitude());
    }

    @Override
    public void onStatusChanged(String s, int i, Bundle bundle) {

    }

    @Override
    public void onProviderEnabled(String s) {

    }

    @Override
    public void onProviderDisabled(String s) {

    }
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        switch (requestCode) {
            case R.integer.Permission_Request_GPS:
                if(!isLocationGranted()){
                    Toast.makeText(this,"位置情報の取得が許可されていません。設定から許可してください。",Toast.LENGTH_LONG).show();
                } else {
                    super.onRequestPermissionsResult(requestCode, permissions, grantResults);
                }
                break;
        }
    }

    //endregion
}
