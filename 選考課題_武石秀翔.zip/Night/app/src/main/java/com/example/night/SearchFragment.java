package com.example.night;

import android.content.res.Resources;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.SearchView;
import android.widget.Toast;


import org.json.JSONArray;

public class SearchFragment extends Fragment {
    private View inflatedView;
    private RecyclerView recycler;
    private Button prevButton, nextButton;
    private JSONArray currentPageContent;
    private int currentPageNumber, pageCount;
    private double latitude, longitude;

    private boolean locationUpdated;
    private int errorCode;
    public void setErrorCode(int code){errorCode=code;}

    public void setLatLon(double lat, double lon) {
        latitude = lat;
        longitude = lon;
        locationUpdated = true;
    }

    public void setPageCount(int num) {
        pageCount = num;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup group, Bundle bundle) {
        super.onCreateView(inflater, group, bundle);
        return inflater.inflate(R.layout.search_view, group, false);
    }

    @Override
    public void onViewCreated(View v, Bundle bundle) {
        super.onViewCreated(v, bundle);
        inflatedView = v;
        initNextButton(inflatedView);
        initPrevButton(inflatedView);
        initSubmitButton(inflatedView);
        initRecycler(inflatedView);
        //キャッシュしておいたPageを再表示
        if (currentPageContent != null) {
            recycler.setAdapter(new ResultAdapter(currentPageContent));
            nextButton.setText("次へ(" + currentPageNumber + "/" + pageCount + ")");
        }
    }

    //region Initializer
    void initRecycler(View inflatedView) {
        recycler = inflatedView.findViewById(R.id.recycler);
        RecyclerView.LayoutManager manager = new LinearLayoutManager(MainActivity.getMainActivity());
        manager.offsetChildrenVertical(5);
        recycler.setLayoutManager(manager);
    }

    void initPrevButton(View inflatedView) {
        prevButton = inflatedView.findViewById(R.id.button_prev);
        if (currentPageContent == null) {
            prevButton.setEnabled(false);
        } else {
            prevButton.setEnabled(currentPageNumber != 1);
        }
        prevButton.setOnClickListener((view) -> {
            currentPageNumber--;
            callAPI();
            if (currentPageNumber == 1) view.setEnabled(false);
            nextButton.setEnabled(true);
            nextButton.setText("次へ(" + currentPageNumber + "/" + pageCount + ")");
        });
    }

    void initNextButton(View inflatedView) {
        nextButton = inflatedView.findViewById(R.id.button_next);
        if (currentPageContent == null) {
            nextButton.setEnabled(false);
        } else {
            nextButton.setEnabled(currentPageNumber < pageCount);
        }
        nextButton.setOnClickListener((view) -> {
            currentPageNumber++;
            callAPI();
            if (currentPageNumber == pageCount) view.setEnabled(false);
            prevButton.setEnabled(true);
            nextButton.setText("次へ(" + currentPageNumber + "/" + pageCount + ")");
        });
    }

    void initSubmitButton(View inflatedView) {
        inflatedView.findViewById(R.id.search_submit).setOnClickListener((view) -> {
            if(!locationUpdated) {
                Toast.makeText(MainActivity.getMainActivity(), "現在地の取得中です。再試行してください。", Toast.LENGTH_LONG).show();
                return;
            }
            currentPageNumber = 1;
            prevButton.setEnabled(false);
            callAPI();
            nextButton.setEnabled(currentPageNumber < pageCount);
            nextButton.setText("次へ(" + currentPageNumber + "/" + pageCount + ")");
        });
    }

    //endregion
    void callAPI() {
        try {
            Bundle bundle = buildBundle();
            JSONArray result = new APICaller(this).execute(bundle).get();
            if(result==null) {
                Resources resources = MainActivity.getMainActivity().getResources();
                if (errorCode == resources.getInteger(R.integer.API_Error_CertificationError)) {
                    Log.e("S_Fragment", "CertificationError");
                } else if (errorCode == resources.getInteger(R.integer.API_Error_ExceededAccessLimit)) {
                    Log.e("S_Fragment", "TooMuchAccess");
                } else if (errorCode == resources.getInteger(R.integer.API_Error_InvalidParameter)) {
                    Log.e("S_Fragment", "InvalidParameter");
                } else if (errorCode == resources.getInteger(R.integer.API_Error_UnauthorizedAccess)) {
                    Log.e("S_Fragment", "AuthorizationError");
                } else if (errorCode == resources.getInteger(R.integer.API_Error_ProcessError)) {
                    Log.e("S_Fragment", "ErrorOccurred While Connection");
                } else if (errorCode == resources.getInteger(R.integer.API_Error_NoResult)) {
                    Toast.makeText(MainActivity.getMainActivity(), "一致するお店は見つかりませんでした。", Toast.LENGTH_LONG).show();
                    Log.e("S_Fragment", "No Result");
                }
            }
            currentPageContent = result;//pageをキャッシュ.
            recycler.setAdapter(new ResultAdapter(result));
        } catch (Exception e) {
            Log.e("S_Fragment.callAPI", e.toString());
        }
    }

    //検索条件をBundleにして提供する
    Bundle buildBundle() {
        Bundle bundle = new Bundle();
        bundle.putInt(getResources().getString(R.string.APICall_page), currentPageNumber);
        RadioGroup radioGroup = inflatedView.findViewById(R.id.RGroup_Range);
        int selected = 2;
        for (int i = 0; i < radioGroup.getChildCount(); i++) {
            if (((RadioButton) radioGroup.getChildAt(i)).isChecked()) {
                selected = i + 1;
                break;
            }
        }
        bundle.putInt(getString(R.string.APICall_range), selected);
        String name = ((SearchView) (inflatedView.findViewById(R.id.search_name))).getQuery().toString();
        bundle.putDouble(getString(R.string.APICall_latitude), latitude);
        bundle.putDouble(getString(R.string.APICall_longitude), longitude);
        bundle.putString(getString(R.string.APICall_name), name);
        bundle.putInt(getString(R.string.APICall_privateRoom), ((CheckBox) inflatedView.findViewById(R.id.search_private_room)).isChecked() ? 1 : 0);
        bundle.putInt(getString(R.string.APICall_buffet), ((CheckBox) inflatedView.findViewById(R.id.search_buffet)).isChecked() ? 1 : 0);
        bundle.putInt(getString(R.string.APICall_free_drink), ((CheckBox) inflatedView.findViewById(R.id.search_free_drink)).isChecked() ? 1 : 0);
        bundle.putInt(getString(R.string.APICall_mid_night), ((CheckBox) inflatedView.findViewById(R.id.search_mid_night)).isChecked() ? 1 : 0);
        bundle.putInt(getString(R.string.APICall_until_morning), ((CheckBox) inflatedView.findViewById(R.id.search_until_morning)).isChecked() ? 1 : 0);
        bundle.putInt(getString(R.string.APICall_no_smoking), ((CheckBox) inflatedView.findViewById(R.id.search_no_smoking)).isChecked() ? 1 : 0);
        return bundle;
    }
}
