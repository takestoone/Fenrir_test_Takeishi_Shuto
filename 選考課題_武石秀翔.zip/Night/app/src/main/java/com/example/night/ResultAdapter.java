package com.example.night;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;



public class ResultAdapter extends RecyclerView.Adapter<ResultAdapter.resultViewHolder> {

    static class resultViewHolder extends RecyclerView.ViewHolder {
        private Bitmap image;
        private ImageView imageView;
        private TextView restaurantName, access, openTime;
        private JSONObject restaurant;

        private void setName(String name) {
            Paint paint = new Paint();
            paint.setUnderlineText(true);
            restaurantName.setPaintFlags(paint.getFlags());
            restaurantName.setTextColor(Color.BLUE);
            restaurantName.setText(name);
        }

        private void setAccess(JSONObject access) {
            try {
                String walk = access.getString("walk");
                try {
                    Integer minute = Integer.parseInt(walk);
                    walk = "徒歩" + minute + "分";
                } catch (Exception e) {
                    walk += "分";
                }
                String accessInfo =
                        access.getString("line")
                                + access.getString("station")
                                + access.getString("station_exit") + "より"
                                + walk;
                this.access.setText(accessInfo);
            } catch (JSONException e) {
                this.access.setText("No data");
                Log.e("ResultAdapter", "setAccess: " + e.toString());
            }
        }

        private void fetchImage(String url) {
            new ImageFetcher(imageView).execute(url);
        }

        private void updateInfo() {
            try {
                setName(restaurant.getString("name"));
                setAccess(restaurant.getJSONObject("access"));
                fetchImage(restaurant.getJSONObject("image_url").getString("shop_image1"));
                this.openTime.setText(restaurant.getString("opentime"));
            } catch (JSONException e) {
                Log.e("ResultAdapter", e.toString());
            }
        }

        public void setRestaurant(JSONObject restaurantJson) {
            restaurant = restaurantJson;
            updateInfo();
            restaurantName.setOnClickListener(view -> {
                MainActivity.getMainActivity().showDetail();
                MainActivity.getMainActivity().getDetailFragment().setRestaurant(restaurant);
            });
        }

        public resultViewHolder(@NonNull View itemView) {
            super(itemView);
            imageView = (ImageView) itemView.findViewById(R.id.recycler_thumbnail);
            imageView.setImageResource(R.drawable.no_image_100);
            restaurantName = (TextView) itemView.findViewById(R.id.recycler_name);
            restaurantName.setWidth(getDisplayWidth() - 200);//Textが見切れるので。
            access = (TextView) itemView.findViewById(R.id.recycler_access);
            access.setWidth(getDisplayWidth() - 200);
            openTime = (TextView) itemView.findViewById(R.id.recycler_open_time);
            openTime.setWidth(getDisplayWidth() - 200);
        }
    }

    static int displayWidth = -1;

    static int getDisplayWidth() {
        if (displayWidth == -1) {
            Point p = new Point();
            MainActivity.getMainActivity().getWindowManager().getDefaultDisplay().getSize(p);
            return p.x;
        } else {
            return displayWidth;
        }
    }

    private JSONArray jsonRestaurantArray;

    @NonNull
    @Override
    public resultViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int position) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.recycler_row, parent, false);
        return new resultViewHolder(v);
    }

    public ResultAdapter(JSONArray array) { jsonRestaurantArray = array; }

    @Override
    public void onBindViewHolder(@NonNull resultViewHolder resultViewHolder, int position) {
        try {
            JSONObject json = jsonRestaurantArray.getJSONObject(position);
            resultViewHolder.setRestaurant(json);
        } catch (JSONException e) {
            Log.e("ResultAdapter.onBind", e.toString());
        }
    }

    @Override
    public int getItemCount() {
        return (jsonRestaurantArray == null) ? 0 : jsonRestaurantArray.length();
    }
}
